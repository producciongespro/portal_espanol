	<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>       
				<a class="navbar-brand visible-xs-block visible-sm-block" href="">Inicio</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav ">
					<li class="active"><a href="index2.php">Listado de artículos</a></li>
					<li><a href="add.php">Agregar artículos</a></li>
					<li><form method='post' action=""> <input type="submit" value="Logout" id="btn_salir" name="but_logout"> </form></li>
				</ul>
			</div><!--/.nav-collapse -->
	</div>